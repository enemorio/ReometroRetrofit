#!/usr/bin/python
import serial

HEADER = '~'
baudrate = 57600
arduino = serial.Serial('/dev/ttyACM0', baudrate)

print("type ok to start readings")
data = raw_input(">> ")
if (data == 'ok'):
    arduino.write(HEADER) #header byte
print("type i or o")
while 1:
  data = raw_input(">> ")
  arduino.write(data)    

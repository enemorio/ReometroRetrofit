#! /usr/bin/python

import serial
import numpy
import time
ser = serial.Serial('/dev/ttyACM0', 9600)
# the arduino resets when it gets a serial connection request
# waiting for 1.5 seconds for the arduino to reset
time.sleep(1.5)
i=0;
ser.write('s')
a=[] # create a list 
while (i<256):
  a.append(ser.readline()) # append to the list
  print(a[i])
  i=i+1

